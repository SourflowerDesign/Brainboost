
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyALzay1XAXv7Eys_dwTVkAxOlblw8dMMHw",
  authDomain: "brainboost-c931f.firebaseapp.com",
  projectId: "brainboost-c931f"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
